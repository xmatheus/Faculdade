[GUIA]
Algoritmo = feito em python3 e foi utilizada as bibliotecas sys, threading e socket
IP && PORTA = por padrão o ip é o localhost e a porta 8080
BlackList = de inicio apenas o site araguaia.ufmt.br esta bloqueado
Arquivos adicionais = pagina HTML quando o host esta bloqueado 